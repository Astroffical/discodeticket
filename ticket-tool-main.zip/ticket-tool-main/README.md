## Discord Ticket Bot Altyapısı!

## 📑 Bot Özellikleri

- [x] Mesaj Geçmişi
- [x] Embed Mesajlar
- [x] Butonlu Sistem

## 📷 Görseller
![image](https://user-images.githubusercontent.com/93944142/204581671-7d362a97-5e6b-46f8-a9dc-cbc1cc64e790.png)
![image](https://user-images.githubusercontent.com/93944142/204582085-2b9d29f3-bc9f-44ba-af2b-e0f99f2dcaf8.png)
![image](https://user-images.githubusercontent.com/93944142/204582134-caa89af5-85d9-4fb4-bbfb-fe69dc4614f8.png)
![image](https://user-images.githubusercontent.com/93944142/204582305-9bccceaf-8759-44d7-8a89-2bddf6646eea.png)

