module.exports = {
    token: "",
    channel: "",
    staff: "" 
}
